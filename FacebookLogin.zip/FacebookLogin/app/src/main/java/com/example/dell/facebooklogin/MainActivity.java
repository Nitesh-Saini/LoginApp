package com.example.dell.facebooklogin;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.ProfileTracker;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    LoginButton loginButton;
    CallbackManager callbackManager;
    AccessTokenTracker accessTokenTracker;
    ProfileTracker profileTracker;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginButton = findViewById(R.id.login_button);
        loginButton.setReadPermissions("email", "public_profile");
        callbackManager = CallbackManager.Factory.create();
        accessTokenTracker = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(AccessToken oldAccessToken, AccessToken currentAccessToken) {

            }
        };
        // If the access token is available already assign it.

        profileTracker = new ProfileTracker() {
            @Override
            protected void onCurrentProfileChanged (Profile oldProfile, Profile newProfile){
                nextActivity(newProfile);

            }
        };
        accessTokenTracker.startTracking();
        profileTracker .startTracking();

        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {

            @Override
            public void onSuccess(LoginResult loginResult) {
                String userid = loginResult.getAccessToken().getUserId();
                Profile profile = Profile.getCurrentProfile();
                nextActivity(profile);
                Toast.makeText(getApplicationContext(),"Loggin in...",Toast.LENGTH_SHORT).show();

                GraphRequest graphRequest = GraphRequest.newMeRequest(loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(JSONObject object, GraphResponse response) {
                        displayUserInfo(object);

                    }
                });

                Bundle parameters = new Bundle();
                parameters.putString("fields","first_name,last_name,email,id");
                graphRequest.setParameters(parameters);
                graphRequest.executeAsync();

            }

            {
                ImageView iv = (ImageView)findViewById(R.id.iv);
                iv.setImageResource(R.drawable.profilepic);
            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException error) {

            }

        });
        
    }
        @Override
            protected void onResume(){
        super.onResume();
        Profile profile = Profile.getCurrentProfile();
        nextActivity(profile);
        }
        @Override
            protected void onPause(){
                super.onPause();
        }
        protected void onStop(){
                super.onStop();
                accessTokenTracker.stopTracking();
                profileTracker.stopTracking();
        }



        @SuppressLint("SetTextI18n")
        public void displayUserInfo(JSONObject object)
    {
        String first_name;
        String last_name;
        String email;
        String id;

            first_name = "";
            last_name = "";
            email = "";
            id = "";
            try{
                first_name = object.getString("first_name");
                last_name = object.getString("last_name");
                email = object.getString("email");
                id = object.getString("id");
            }
            catch (JSONException e){
                e.printStackTrace();
            }
            TextView tv_name,tv_email,tv_age,tv_id;
            tv_name= findViewById(R.id.TV_name);
            tv_email= findViewById(R.id.TV_email);

            tv_id= findViewById(R.id.TV_id);

            tv_name.setText(last_name+" "+first_name);
            tv_email.setText("Email: "+email);

            tv_id.setText("ID : "+id);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void nextActivity(Profile profile){
            if(profile!=null){
            }
    }
}
